#include<iostream>
#include<cstring>


using namespace std;

class Auction
{
private:
int Auction_ID;
char Auction_Name[20];
char Auction_Type[30];

public:
Auction();
Auction(int A_ID, const char A_Name[], const char A_Type[]);
void DisplayAuction();
void CalculatePrice();

~Auction();
};

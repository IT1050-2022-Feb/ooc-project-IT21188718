#include <iostream>
#include "Auction.h"
#include <cstring>
using namespace std;
Auction::Auction()
{
Auction_ID = 0;
strcpy(Auction_Name, "");
strcpy(Auction_Type, "");

}

Auction::Auction(int A_ID, const char A_Name[], const char A_Type[])

{
Auction_ID = A_ID;
strcpy(Auction_Name, A_Name);
strcpy(Auction_Type, A_Type);
}

void Auction::DisplayAuction()
{

}
void Auction::CalculatePrice()
{

}
Auction::~Auction()
{
//Destructor 
}
